package edu.citytech.cst.games;

public class PossibleWinner {

	public int p1, p2, p3;

	public PossibleWinner(int p1, int p2, int p3) {
		super();
		this.p1 = p1;
		this.p2 = p2;
		this.p3 = p3;

	}

	@Override
	public String toString() {
		return "PossibleWinner [p1=" + p1 + ", p2" + p2 + ", p3" + p3 + "]";
	};
	
	
	public static void checkWinner() {
		
	}
	
}
